<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.101.0">
    <title>Signin Template · Bootstrap v4.6</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.6/examples/sign-in/">

    

    <!-- Bootstrap core CSS -->
<link href="<?= base_url()?>assets/dist/css/bootstrap.min.css" rel="stylesheet">



    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="<?= base_url()?>assets/signin.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">
        <div class="row" style="margin-top: 3rem;">
        <div class="col-md-12">
            <div class="d-flex justify-content-center">
                <div class="card" style="width: 50%; border-radius: 10%;">
                <div class="card-body">
                <form class="form-signin" action="<?= base_url("User/register")?>" method="post">
  <img class="mb-4" style="margin-left: auto; margin-right: auto; margin:auto; display:block;" src="<?= base_url()?>assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">
  <h1 class="h3 mb-3 font-weight-normal text-center">Please sign in</h1>
  <div class="form-group">
  <label for="inputEmail" class="">Email</label>
  <input type="email" id="inputEmail" name="Email" class="form-control" placeholder="Email address" required autofocus>
  </div>
  <div class="form-group">
  <label for="inputPassword" class="">Nama Lengkap</label>
  <input type="text" id="inputPassword" name="Nama_lengkap" class="form-control" placeholder="Nama Lengkap" required>
  </div>
  <div class="form-group">
  <label for="inputPassword" class="">Username</label>
  <input type="text" id="inputPassword" name="Username" class="form-control" placeholder="Username" required>
  </div>
  <div class="form-group">
  <label for="inputPassword" class="">Password</label>
  <input type="password" id="inputPassword" name="Password" class="form-control" placeholder="Password" required>
  </div>
  <div class="form-group">
  <label for="inputPassword" class="">Alamat</label>
  <textarea type="text" id="inputPassword" name="Alamat" class="form-control" placeholder="Alamat" required></textarea>
  </div>
  <div class="checkbox mb-3">
    <label>
      <input type="checkbox" value="remember-me"> Remember me
    </label>
  </div>
  <button class="btn btn-lg btn-primary btn-block" type="submit">Buat Akun</button>
  <p class="mt-5 mb-3 text-muted">&copy; 2017-2022</p>
</form>
                </div>
            </div>
            </div>
        </div>
    </div>
    </div>
  </body>
</html>
