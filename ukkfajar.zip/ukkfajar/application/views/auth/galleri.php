<?php if($this->session->userdata("logged") == TRUE) {?>
<button type="button" class="btn btn-primary mt-3" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
</svg>Tambah Foto</button>
<?php } ?>
<!-- Tampilin Foto -->
<div class="container-xl">
  <div class="row row-cards">
    <?php foreach ($photo as $pho) : ?>
      <div class="col-sm-6 col-lg-3">
        <div class="card card-sm">
          <a href="<?= base_url("Galleri/detail/" . $pho->FotoID) ?>" class="d-block"><img src="<?= base_url() ?>Foto/<?php echo $pho->LokasiFile ?>" width="350" height="200" class="card-img-top"></a>
          <div class="card-body">
            <div class="d-flex align-items-center">
              <span class="avatar me-3 rounded" style="background-image: url(<?= base_url(); ?>);"></span>
              <div>
                <div>
                  <h5 class="text-muted"><?= $pho->JudulFoto ?></h5>
                </div>
                <div>
                  <h6 class="text-info"><?= $pho->Username ?></h6>
                </div>
                <div class="text-secondary"><?= date("d F Y", strtotime($pho->TanggalUnggah)); ?>

                </div>
                <div class="ms-auto">
                  <?php if ($this->session->userdata("logged") == TRUE) { ?>
                      <?php echo anchor("Galleri/like/" . $pho->FotoID, '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" color="red" fill="currentColor" class="bi bi-heart" viewBox="0 0 16 16">
      <path d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143q.09.083.176.171a3 3 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15"/>
      </svg>'); ?>
      <?= $pho->jumlah_like ?>

      <?php echo anchor("Galleri/detail/" . $pho->FotoID, '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" color="black" fill="currentColor" class="bi bi-chat-text" viewBox="0 0 16 16">
  <path d="M2.678 11.894a1 1 0 0 1 .287.801 11 11 0 0 1-.398 2c1.395-.323 2.247-.697 2.634-.893a1 1 0 0 1 .71-.074A8 8 0 0 0 8 14c3.996 0 7-2.807 7-6s-3.004-6-7-6-7 2.808-7 6c0 1.468.617 2.83 1.678 3.894m-.493 3.905a22 22 0 0 1-.713.129c-.2.032-.352-.176-.273-.362a10 10 0 0 0 .244-.637l.003-.01c.248-.72.45-1.548.524-2.319C.743 11.37 0 9.76 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7-3.582 7-8 7a9 9 0 0 1-2.347-.306c-.52.263-1.639.742-3.468 1.105"/>
  <path d="M4 5.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5M4 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 4 8m0 2.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5"/>
</svg>'); ?>
<?= $pho->jumlah_komen ?>
      
                    <?php if ($this->session->userdata("UserID") == $pho->UserID) { ?>
                      <?php echo anchor("Galleri/edit/" . $pho->FotoID, '<a href="" data-toggle="modal" data-target="#editFoto"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
              </svg></a>'); ?>
                      <?php echo anchor("Galleri/hapus/" . $pho->FotoID, '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" color="red" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16">
  <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5m-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5M4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06m6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528M8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5"/>
</svg>'); ?>
                    <?php } ?>
                  <?php } ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>

  </div>
</div>

<!-- Form Tambah Foto -->
<?= form_open_multipart(base_url("Galleri/tambahFoto")); ?>
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Foto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="">
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Judul Foto</label>
            <input type="text" name="JudulFoto" class="form-control" id="JudulFoto">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">File foto</label>
            <input type="file" name="berkas" class="form-control-file" id="berkas">
          </div>
          <input type="hidden" name="Tanggal" class="form-control-file" id="Tanggal" value="<?= date("Y-M-d") ?>">
          <input type="hidden" name="user" class="form-control-file" id="user" value="<?= $this->session->userdata("Username"); ?>">

          <div class="form-group">
            <label for="exampleFormControlSelect1">Album</label>
            <?php if ($dataAlbum) : ?>
              <select class="form-control" id="Album" name="Album">
                <?php foreach ($dataAlbum as $row) : ?>
                  <option value="<?= $row->AlbumID; ?>"><?= $row->NamaAlbum; ?></option>
                <?php endforeach; ?>
              </select>
            <?php else : ?>
              <select class="form-control" id="Album" name="Album">
                <option value=""></option>
              <?php endif; ?>
          </div>
          <div class="form-group">
            <label for="exampleFormControlSelect1">Kategori</label>
            <select class="form-control" id="Kategori" name="Kategori">
              <?php foreach ($dataKategori as $rows) : ?>
                <option value="<?= $rows->KategoriID; ?>"><?= $rows->kategoriNama; ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="form-group">
            <label for="message-text" class="col-form-label">Deskripsi</label>
            <textarea class="form-control" name="Deskripsi" id="message-text"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <button type="submit" name="submit" class="btn btn-primary">Tambah</button>
        <?= form_close() ?>
      </div>
    </div>
  </div>
</div>

<!-- /Form edit foto/ -->
<?php foreach ($photo as $pho) : ?>
  <?= form_open_multipart(base_url("Galleri/edit")); ?>
  <div class="modal fade" id="editFoto" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Tambah Foto</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body">
          <form method="post" action="">
            <div class="form-group">
              <label for="recipient-name" class="col-form-label">Judul Foto</label>
              <input type="hidden" name="FotoID" class="form-control" id="FotoID" value="<?= $pho->FotoID; ?>">
              <input type="text" name="JudulFoto" class="form-control" id="JudulFoto">
            </div>
            <div class="form-group">
              <label for="recipient-name" class="col-form-label">File foto</label>
              <input type="file" name="berkas" class="form-control-file" id="berkas">
            </div>
            <input type="hidden" name="Tanggal" class="form-control-file" id="Tanggal" value="<?= date("Y-M-d") ?>">
            <input type="hidden" name="user" class="form-control-file" id="user" value="<?= $this->session->userdata("Username"); ?>">

            <div class="form-group">
              <label for="exampleFormControlSelect1">Album</label>
              <?php if ($dataAlbum) : ?>
                <select class="form-control" id="Album" name="Album">
                  <?php foreach ($dataAlbum as $row) : ?>
                    <option value="<?= $row->AlbumID; ?>"><?= $row->NamaAlbum; ?></option>
                  <?php endforeach; ?>
                </select>
              <?php else : ?>
                <select class="form-control" id="Album" name="Album">
                  <option value=""></option>
                <?php endif; ?>
            </div>
            <div class="form-group">
              <label for="exampleFormControlSelect1">Kategori</label>
              <select class="form-control" id="Kategori" name="Kategori">
                <?php foreach ($dataKategori as $rows) : ?>
                  <option value="<?= $rows->KategoriID; ?>"><?= $rows->kategoriNama; ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="form-group">
              <label for="message-text" class="col-form-label">Deskripsi</label>
              <textarea class="form-control" name="Deskripsi" id="message-text"></textarea>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
          <button type="submit" name="submit" class="btn btn-primary">Tambah</button>
          <?= form_close() ?>
        </div>
      </div>
    </div>
  </div>
<?php endforeach; ?>