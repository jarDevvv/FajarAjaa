<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="<?= base_url("assets/dist/css/style.css")?>">
    <title><?= $title ?></title>
  </head>
  <body style="background-color: aliceblue ;">
  <nav class="navbar navbar-expand-lg navbar-light bg-secondary">
  <a class="navbar-brand" href="<?= base_url("Home")?>">GALPHOT</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav ml-auto">
      <a class="nav-link" href="<?= base_url("Galleri/galleri")?>">Galeri</a>
      <?php if($this->session->userdata("logged") != TRUE) {?>
      <a class="nav-link" href="<?= base_url("User/login")?>">Login</a>
      <a class="nav-link" href="<?= base_url("User/register")?>">Register</a>
     <?php } ?>
      <?php if($this->session->userdata("logged") == TRUE) {?>
        <a class="nav-link" href="<?= base_url("Album")?>">Album</a>
        <a class="nav-link" href="<?= base_url("User/logout")?>">Logout</a>
        <?php } ?>
    </div>
  </div>
</nav>