<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
    public function __construct(){
        parent:: __construct();
        $this->load->library("form_validation");
    }

    public function register() {
        $this->form_validation->set_rules("Email", "email", "required|trim|valid_email");
        $this->form_validation->set_rules("Nama_lengkap", "nama_lengkap", "required|trim");
        $this->form_validation->set_rules("Username", "username", "required|trim");
        $this->form_validation->set_rules("Password", "password", "required|trim|min_length[3]");
        $this->form_validation->set_rules("Alamat", "alamat", "required|trim");
        if($this->form_validation->run() == false) {
            $data["title"] = "Registrasi";
            $this->load->view("auth/register");
        } else {
            $Email = ($this->input->post("Email", true));
            $Nama_lengkap =($this->input->post("Nama_lengkap", true));
            $Username = ($this->input->post("Username", true));
            $Password = password_hash($this->input->post("Password"), PASSWORD_DEFAULT);
            $Alamat = $this->input->post("Alamat");
            $level = "Admin";

            $data = [
                "Email" => $Email,
                "Nama_lengkap" => $Nama_lengkap,
                "Username" => $Username,
                "Password" => $Password,
                "Alamat" => $Alamat,
                "Level" => $level
            ];
            $this->load->model("M_verifikasi");
            $this->M_verifikasi->addakun($data);
            redirect("Home");
        }
    }
    public function login(){
        $this->form_validation->set_rules("Username", "username", "required|trim");
        $this->form_validation->set_rules("Password", "password", "required|trim");
        if($this->form_validation->run() == false){
            $data["title"] = "Login";
            $this->load->view("auth/login", $data);
        } else {
            $Username = $this->input->post("Username");
            $Password = $this->input->post("Password");

            $user = $this->db->get_where("user", ["Username" => $Username])->row_array();

            if($user){
                if(password_verify($Password, $user["Password"])) {
                    $data =[
                        "UserID" => $user["UserID"],
                        "Email" => $user["Email"],
                        "Nama_lengkap" => $user["Nama_lengkap"],
                        "Username" => $user["Username"],
                        "Password" => $user["Password"],
                        "Alamat" => $user["Alamat"],
                        "Level" => $user["Level"]
                    ];
                    $this->session->set_userdata($data);
                    $this->session->set_userdata("logged", TRUE);
                    redirect("Home");
                } else {
                    $this->session->set_flashdata("errorPassword", "Password anda salah!");
                    redirect("User/login");
                }
            } else {
                $this->session->set_flashdata("error", "Username anda belum terdaftar");
                redirect("User/login");
            }
        }
    }

    public function logout() {
        $this->session->unset_userdata("UserID");
        $this->session->unset_userdata("Email");
        $this->session->unset_userdata("Nama_lengkap");
        $this->session->unset_userdata("Username");
        $this->session->unset_userdata("Password");
        $this->session->unset_userdata("Alamat");
        $this->session->unset_userdata("Level");
        $this->session->unset_userdata("logged");
        redirect("Home");
    }
}
