<?php
class Album extends CI_Controller {
    public function __construct()
    {
        parent:: __construct();
        $this->load->library("form_validation");
        $this->load->model("M_verifikasi");
    }

    public function index(){
        $data["title"] ="Album";
        $data["album"] = $this->M_verifikasi->dataAlbum();
        $this->load->view("template/header", $data);
        $this->load->view("auth/album");
        $this->load->view("template/footer");
    }

    public function tambahAlbum(){
        $NamaAlbum = $this->input->post("NamaAlbum");
        $Deskripsi = $this->input->post("Deskripsi");
        $TanggalDibuat = date("Y-m-d H:i:s");
        $user = $this->input->post("UserID");

        $akun = $this->db->get_where("user", ["Username" => $this->db->escape_str($user)])->row_array();

        $data = [
            "NamaAlbum" => $NamaAlbum,
            "Deskripsi" => $Deskripsi,
            "TanggalDibuat" => $TanggalDibuat,
            "UserID" => $akun["UserID"],

        ];

        $this->M_verifikasi->addAlbum("album", $data);
        redirect("Album");
    }

    public function hapus($AlbumID){
        $where = array("AlbumID" => $AlbumID);
        $this->M_verifikasi->hapusAlbum($where, "album");
        redirect("Album");
    }

    public function edit() {
        $akun = $this->db->get_where("user", ["Username" => $this->input->post("UserID")])->row_array();
;

        $AlbumID = $this->input->post("AlbumID");
        $NamaAlbum = $this->input->post("NamaAlbum");
        $Deskripsi = $this->input->post("Deskripsi");
        $TanggalDibuat = date("Y-m-d H:i:s");

        $data = array (
            "NamaAlbum" => $NamaAlbum,
            "Deskripsi" => $Deskripsi,
            "TanggalDibuat" => $TanggalDibuat,
            "UserID" => $akun["UserID"]
        );

        $where = array (
            "AlbumID" => $AlbumID

        );

        $this->M_verifikasi->editAlbum($where, $data, "album");
        redirect("Album");
    }
}
?>