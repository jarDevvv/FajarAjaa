<?php 
class Galleri extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->library("form_validation");
        $this->load->model("M_verifikasi");
    }

    public function galleri(){
        $data["user"] = $this->db->get_where("user", ["Username" => $this->session->userdata("Username")])->row_array();
        $data["dataAlbum"] = $this->M_verifikasi->dataAlbum();
        $data["dataKategori"] = $this->M_verifikasi->getKategori();
        $data["photo"] = $this->M_verifikasi->postFoto();
        $data["title"] = "Galleri";
        $this->load->view("template/header",$data);
        $this->load->view("auth/galleri");
        $this->load->view('template/footer');

    }

    public function detail($photo){
        $data["title"] = "Detail";
        $data["photo"] = $this->M_verifikasi->detailGambar($photo)->result();
        $data["FotoID"] = $photo;
        $data["komentar"] = $this->M_verifikasi->getAllkomen($photo);
        $this->load->view("Template/header", $data);
        $this->load->view("auth/detail", $data);
        $this->load->view("template/footer");
    }
    public function tambahFoto(){
        $akun = $this->db->get_where("user", ["Username" => $this->input->post("user")])->row_array();

        $config["upload_path"] = "./Foto";
        $config["allowed_types"] = "gif|jpg|png";
        $config["file_name"] = $_FILES["berkas"]["name"];

        $this->load->library("upload", $config);
        if(!$this->upload->do_upload("berkas")){
            $error = array("error" => $this->upload->display_errors());
            echo var_dump($error);
        } else {
            $uploadData = $this->upload->data();
            $filename = $uploadData["file_name"];
            $data = [
                "LokasiFile" => $filename,
                "JudulFoto" => $this->input->post("JudulFoto"),
                "Deskripsi" => $this->input->post("Deskripsi"),
                "TanggalUnggah" => date('Y-m-d H:i:s'),
                "AlbumID" => $this->input->post("Album"),
                "KategoriID" => $this->input->post("Kategori"),
                "UserID" => $akun["UserID"]
            ];

            $this->M_verifikasi->insertFoto($data,"foto");
            redirect("Galleri/galleri");
        }
    }

    public function hapus($FotoID){
        $where = array("FotoID" => $FotoID);
        $this->M_verifikasi->hapus_foto($where,"foto");
        redirect("Galleri/galleri");
    }

    public function edit(){
        $akun = $this->db->get_where("user", ["Username" => $this->input->post("user")])->row_array();
        $config["upload_path"] = "./Foto";
        $config["allowed_types"] = "gif|jpg|png";
        $config["file_name"] = $_FILES["berkas"]["name"];

        $this->load->library("upload", $config);
        if(!$this->upload->do_upload("berkas")){
            $error = array("error" => $this->upload->display_errors());
            echo var_dump($error);
        } else {
            $uploadData = $this->upload->data();
            $filename = $uploadData["file_name"];
            $FotoID = $this->input->post("FotoID");
            $data = [
                "LokasiFile" => $filename,
                "JudulFoto" => $this->input->post("JudulFoto"),
                "Deskripsi" => $this->input->post("Deskripsi"),
                "TanggalUnggah" => date('Y-m-d H:i:s'),
                "AlbumID" => $this->input->post("Album"),
                "KategoriID" => $this->input->post("Kategori"),
                "UserID" => $akun["UserID"]
            ];

            $this->db->where("FotoID", $FotoID);
            $this->db->update("foto", $data);
            redirect("Galleri/galleri");
        }
    }

    public function komentar(){
   // Ambil data yang diposting
   $FotoID = $this->input->post("FotoID");
   $Komentar = $this->input->post("Komentar");
   $user = $this->session->userdata("UserID");

       // Buat array data untuk disimpan
       if(!empty($Komentar)){
       $data = [
           "FotoID" => $FotoID,
           "UserID" => $user,
           "IsiKomentar" => $Komentar,
           "TanggalKomentar" => date('Y-m-d H:i:s') // Tanggal komentar saat ini
       ];
       
       // Panggil model untuk menyimpan komentar
       $this->M_verifikasi->insertKomen($data);
    }
       redirect('Galleri/detail/'.$FotoID);
    }

    public function like($FotoID){
        $UserID = $this->session->userdata("UserID");
        $oldLike = $this->db->get_where("likefoto", array("FotoID" => $FotoID, "UserID" => $UserID))->row();

        if($oldLike) {
            $this->db->where("LikeID", $oldLike->LikeID);
            $this->db->delete("likefoto");
        } else {
            $data = [
                "FotoID" => $FotoID,
                "UserID" => $UserID,
                "TanggalLike" => date("Y-m-d H:i:s"),
            ];
            $this->db->insert("likefoto", $data);
        }

        redirect("Galleri/galleri");
    }

}
?>