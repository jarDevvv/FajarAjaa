<?php
class M_verifikasi extends CI_Model {
    public function addakun($data) {
        $this->db->insert("user", $data);
    }
//Data Foto
    public function insertFoto($data){
        
        $this->db->insert("foto", $data);
    }

    public function getFoto(){

        $query = $this->db->get("foto");
        return $query->result();
    }

    public function postFoto(){
        $this->db->select("user.Username, user.UserID, foto.FotoID, foto.JudulFoto, foto.Deskripsi, foto.TanggalUnggah, foto.LokasiFile, foto.AlbumID, foto.UserID, foto.KategoriID, kategori.KategoriID, kategori.kategoriNama");
        $subquery_like = '(SELECT COUNT(LikeID) FROM likefoto WHERE FotoID = foto.FotoID) as jumlah_like';
        $this->db->select($subquery_like, FALSE);
        $subquery_komen = '(SELECT COUNT(KomentarID) FROM komentarfoto WHERE FotoID = foto.FotoID) as jumlah_komen';
        $this->db->select($subquery_komen, FALSE);
        $this->db->from("foto");
        $this->db->join("user", "user.UserID = foto.UserID", "left");
        $this->db->join("kategori", "foto.KategoriID = kategori.KategoriID", "left");
        $query = $this->db->get();
        return $query->result();
    }

    public function hapus_foto($where, $table){
        if ($table === 'foto') {
            $this->hapusLikeTerkait($where['FotoID']);
        }
        
        // Hapus entri di tabel induk setelah semua entri di tabel anak sudah dihapus
        $this->db->where($where);
        $this->db->delete($table);
    }
    
    // Fungsi untuk menghapus foto terkait di tabel anak (foto) berdasarkan AlbumID
    private function hapusLikeTerkait($FotoID) {
        $this->db->where('FotoID', $FotoID);
        $this->db->delete('likefoto');
    }

    public function detailGambar($photo){
        $this->db->select("*");
        $this->db->from("foto");
        $this->db->order_by("FotoID", "ASC");
        $this->db->where("FotoID", $photo);
        return $this->db->get();
    }

    public function insertKomen($data){
        $this->db->insert("komentarfoto",$data);
        return $this->db->insert_id();    
    }

    public function getAllkomen($FotoID){
        $this->db->select("user.Username, user.UserID, komentarfoto.KomentarID, komentarfoto.IsiKomentar, komentarfoto.UserID, komentarfoto.FotoID, komentarfoto.TanggalKomentar");
        $this->db->from("komentarfoto");
        $this->db->join("user", "user.UserID = komentarfoto.UserID", "left");
        $this->db->where('komentarfoto.FotoID', $FotoID);
        $query = $this->db->get();
        return $query->result();
    }
//Data Album
    public function addAlbum($table, $data){
        $this->db->insert($table, $data);
    }
    public function getAlbum(){
        return $this->db->get("album");
    }

    public function dataAlbum(){
        $user = $this->session->userdata("UserID");
        
        if($user) {
            $this->db->where("UserID", $user);
            return $this->db->get("album")->result();
        } else {
            return[];
        }
    }

    // public function hapusAlbum($where, $table){
    //     $this->db->where($where);
    //     $this->db->delete($table);
    // }
    public function hapusAlbum($where, $table){
        // Hapus terlebih dahulu semua entri yang terkait di tabel anak (misalnya, tabel foto)
        if ($table === "album") {
            $this->hapusFotoTerkait($where["AlbumID"]);
        }
        
        // Hapus entri di tabel induk setelah semua entri di tabel anak sudah dihapus
        $this->db->where($where);
        $this->db->delete($table);
    }
    
    // Fungsi untuk menghapus foto terkait di tabel anak (foto) berdasarkan AlbumID
    private function hapusFotoTerkait($AlbumID) {
        $this->db->where("AlbumID", $AlbumID);
        $this->db->delete("foto");
    }
    

    public function editAlbum($where, $data, $table) {
        $this->db->where($where);
        $this->db->update($table, $data);
    }
    
    //Kategori
    public function getKategori(){
        $query = $this->db->get("kategori");
        return $query->result();
    }
}
?>